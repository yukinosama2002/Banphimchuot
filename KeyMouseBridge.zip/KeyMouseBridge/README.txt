KeyMouseBridge - build APK
1) Android Studio: File > Open (thư mục này) > Build > Build APK(s)
   -> app/build/outputs/apk/debug/app-debug.apk
2) Không cài gì: đẩy thư mục này lên GitHub, tab Actions > "Build APK" > Run workflow,
   tải file KeyMouseBridge-apk ở cuối trang chạy.
PC: python pc_client.py <IP> <PIN>
