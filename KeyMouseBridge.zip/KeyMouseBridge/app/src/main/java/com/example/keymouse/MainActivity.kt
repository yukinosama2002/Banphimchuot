package com.example.keymouse

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val info = TextView(this).apply { textSize = 18f }
        val btn = Button(this).apply {
            text = "Bật dịch vụ trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(info)
            addView(btn)
        })

        info.text = "IP: ${localIp()}\nCổng: ${InputService.PORT}\nPIN: ${InputService.pin(this)}\n\n" +
            "1) Bật 'Key Mouse Bridge' trong Trợ năng\n" +
            "2) Trên PC: python pc_client.py <IP> <PIN>\n"
    }

    private fun localIp(): String =
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }
            ?.hostAddress ?: "?"
}
