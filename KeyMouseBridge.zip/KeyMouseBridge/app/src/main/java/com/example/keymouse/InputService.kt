package com.example.keymouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import kotlin.concurrent.thread
import kotlin.math.hypot
import kotlin.math.min

/**
 * Nhận lệnh từ PC qua TCP và chuyển thành thao tác cảm ứng / gõ chữ
 * trong MỌI ứng dụng (dùng AccessibilityService, không cần root).
 *
 * Giao thức (mỗi lệnh 1 dòng):
 *   AUTH <pin>      dòng đầu tiên bắt buộc
 *   P x y           vị trí chuột, tỉ lệ 0..1 của màn hình
 *   D b / U b       nhấn / nhả nút chuột (0 trái, 1 giữa, 2 phải)
 *   S d             lăn chuột (+1 lên, -1 xuống)
 *   K name 1|0      phím nhấn / nhả
 *   R               nhả tất cả
 */
class InputService : AccessibilityService() {

    companion object {
        const val PORT = 9000

        fun pin(ctx: Context): String {
            val sp = ctx.getSharedPreferences("km", Context.MODE_PRIVATE)
            return sp.getString("pin", null)
                ?: (100000 + SecureRandom().nextInt(900000)).toString()
                    .also { sp.edit().putString("pin", it).apply() }
        }
    }

    // ===== Bản đồ phím cho game: phím -> vị trí nút trên màn hình (tỉ lệ 0..1) =====
    // Chỉnh theo bố cục từng game. WASD / phím mũi tên điều khiển joystick bên dưới.
    private val keymap: Map<String, Pair<Float, Float>> = mapOf(
        "space" to (0.88f to 0.78f),
        "e" to (0.80f to 0.55f),
        "r" to (0.70f to 0.85f),
        "f" to (0.60f to 0.60f),
        "q" to (0.92f to 0.50f),
        "shift_l" to (0.80f to 0.80f),
        "1" to (0.40f to 0.92f),
        "2" to (0.46f to 0.92f),
        "3" to (0.52f to 0.92f),
        "4" to (0.58f to 0.92f),
    )
    // Tâm joystick (x, y) và bán kính, tính theo tỉ lệ màn hình
    private val joyX = 0.14f
    private val joyY = 0.68f
    private val joyR = 0.12f

    // ===== Trạng thái ngón tay ảo =====
    private class Ptr(val id: String, var x: Float, var y: Float, val dur: Long = 30L) {
        var tx = x
        var ty = y
        var stroke: StrokeDescription? = null
        var ending = false
        fun dirty() = stroke == null || ending || tx != x || ty != y
    }

    private class Sent(val p: Ptr, val s: StrokeDescription, val ex: Float, val ey: Float)

    private val ui = Handler(Looper.getMainLooper())
    private val ptrs = LinkedHashMap<String, Ptr>()
    private val dirs = HashSet<String>()
    private var busy = false
    private var kicked = false
    private var server: ServerSocket? = null

    private lateinit var wm: WindowManager
    private lateinit var cursor: CursorView
    private lateinit var lp: LP
    private var sw = 1
    private var sh = 1
    private var cx = 0f
    private var cy = 0f

    // ===== Vòng đời =====
    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        measure()
        cx = sw / 2f
        cy = sh / 2f

        val d = resources.displayMetrics.density
        cursor = CursorView(this).apply { visibility = View.INVISIBLE }
        lp = LP(
            (24 * d).toInt(), (32 * d).toInt(),
            LP.TYPE_ACCESSIBILITY_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or
                LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(cursor, lp)
        moveCursor()
        startServer()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (::wm.isInitialized) {
            measure()
            cx = cx.coerceIn(0f, sw - 1f)
            cy = cy.coerceIn(0f, sh - 1f)
            moveCursor()
        }
    }

    override fun onDestroy() {
        try { server?.close() } catch (e: Exception) {}
        try { if (::cursor.isInitialized) wm.removeView(cursor) } catch (e: Exception) {}
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun measure() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels
    }

    // ===== Mạng =====
    private fun startServer() {
        thread(isDaemon = true) {
            try {
                val ss = ServerSocket(PORT).also { server = it }
                while (!ss.isClosed) {
                    val s = ss.accept()
                    s.tcpNoDelay = true
                    thread(isDaemon = true) { serve(s) }
                }
            } catch (e: Exception) {}
        }
    }

    private fun serve(s: Socket) {
        s.use {
            it.soTimeout = 5000
            val r = it.getInputStream().bufferedReader()
            val first = try { r.readLine()?.trim() } catch (e: Exception) { null }
            if (first != "AUTH " + pin(this)) {
                Thread.sleep(1000) // làm chậm dò PIN
                return
            }
            it.soTimeout = 0
            ui.post { cursor.visibility = View.VISIBLE }
            try { r.forEachLine { l -> ui.post { handle(l) } } } catch (e: Exception) {}
            ui.post { releaseAll(); cursor.visibility = View.INVISIBLE }
        }
    }

    private fun handle(line: String) {
        val a = line.trim().split(' ')
        try {
            when (a[0]) {
                "P" -> {
                    cx = (a[1].toFloat() * sw).coerceIn(0f, sw - 1f)
                    cy = (a[2].toFloat() * sh).coerceIn(0f, sh - 1f)
                    moveCursor()
                    pointerMove("mouse", cx, cy)
                }
                "D" -> when (a[1]) {
                    "0" -> pointerDown("mouse", cx, cy)
                    "1" -> performGlobalAction(GLOBAL_ACTION_HOME)  // chuột giữa
                    "2" -> performGlobalAction(GLOBAL_ACTION_BACK)  // chuột phải
                }
                "U" -> if (a[1] == "0") pointerUp("mouse")
                "S" -> scroll(a[1].toFloat())
                "K" -> key(a[1], a[2] == "1")
                "R" -> releaseAll()
            }
        } catch (e: Exception) {}
    }

    // ===== Chuột =====
    private fun moveCursor() {
        lp.x = cx.toInt()
        lp.y = cy.toInt()
        wm.updateViewLayout(cursor, lp)
    }

    private fun scroll(dir: Float) {
        if (ptrs.containsKey("scroll")) return
        pointerDown("scroll", cx, cy, 150L)
        pointerMove("scroll", cx, cy + dir * 0.2f * sh) // lăn lên = vuốt xuống
        pointerUp("scroll")
    }

    // ===== Bàn phím =====
    private fun key(raw: String, down: Boolean) {
        val k = raw.lowercase()

        // Phím hệ thống
        val global = when (k) {
            "escape" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "f2" -> GLOBAL_ACTION_RECENTS
            else -> null
        }
        if (global != null) { if (down) performGlobalAction(global); return }

        // Đang có ô nhập chữ -> gõ chữ
        editableFocus()?.let { if (down) typeKey(it, raw); return }

        // Chế độ game: WASD / mũi tên -> joystick
        val d = when (k) {
            "w", "up" -> "w"
            "a", "left" -> "a"
            "s", "down" -> "s"
            "d", "right" -> "d"
            else -> null
        }
        if (d != null) {
            if (down) dirs.add(d) else dirs.remove(d)
            updateJoystick()
            return
        }

        // Phím khác -> chạm vào vị trí đã gán
        val p = keymap[k] ?: return
        val id = "k_$k"
        if (down) pointerDown(id, p.first * sw, p.second * sh) else pointerUp(id)
    }

    private fun updateJoystick() {
        var dx = 0f
        var dy = 0f
        if ("a" in dirs) dx -= 1f
        if ("d" in dirs) dx += 1f
        if ("w" in dirs) dy -= 1f
        if ("s" in dirs) dy += 1f
        if (dx == 0f && dy == 0f) { pointerUp("joy"); return }

        val len = hypot(dx, dy)
        val r = joyR * min(sw, sh)
        if (!ptrs.containsKey("joy")) pointerDown("joy", joyX * sw, joyY * sh)
        pointerMove("joy", joyX * sw + dx / len * r, joyY * sh + dy / len * r)
    }

    private fun editableFocus(): AccessibilityNodeInfo? =
        findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }

    // Gõ vào cuối ô nhập (đơn giản hoá: không theo vị trí con trỏ)
    private fun typeKey(n: AccessibilityNodeInfo, raw: String) {
        val base = if (n.isShowingHintText) "" else n.text?.toString().orEmpty()
        val out: String = when (raw.lowercase()) {
            "backspace" -> base.dropLast(1)
            "space" -> "$base "
            "return", "kp_enter" -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                    return
                }
                base + "\n"
            }
            else -> if (raw.codePointCount(0, raw.length) == 1) base + raw else return
        }
        n.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, out)
            }
        )
        n.performAction(
            AccessibilityNodeInfo.ACTION_SET_SELECTION,
            Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, out.length)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, out.length)
            }
        )
    }

    // ===== Bộ máy đa chạm: mọi "ngón" gộp vào cùng một gesture =====
    private fun pointerDown(id: String, x: Float, y: Float, dur: Long = 30L) {
        if (ptrs.containsKey(id)) return
        ptrs[id] = Ptr(id, x.coerceIn(0f, sw - 1f), y.coerceIn(0f, sh - 1f), dur)
        kick()
    }

    private fun pointerMove(id: String, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        p.tx = x.coerceIn(0f, sw - 1f)
        p.ty = y.coerceIn(0f, sh - 1f)
        kick()
    }

    private fun pointerUp(id: String) {
        val p = ptrs[id] ?: return
        p.ending = true
        kick()
    }

    private fun releaseAll() {
        dirs.clear()
        ptrs.values.forEach { it.ending = true }
        kick()
    }

    private fun kick() {
        if (kicked) return
        kicked = true
        ui.post { kicked = false; pump() }
    }

    private fun pump() {
        if (busy || ptrs.isEmpty() || ptrs.values.none { it.dirty() }) return

        val b = GestureDescription.Builder()
        val sent = ArrayList<Sent>()
        for (p in ptrs.values.take(9)) {
            val ex = p.tx
            val ey = p.ty
            val path = Path().apply {
                moveTo(p.x, p.y)
                if (ex != p.x || ey != p.y) lineTo(ex, ey)
            }
            val more = !p.ending
            val s = p.stroke?.continueStroke(path, 0L, p.dur, more)
                ?: StrokeDescription(path, 0L, p.dur, more)
            b.addStroke(s)
            sent += Sent(p, s, ex, ey)
        }

        busy = true
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                for (t in sent) {
                    t.p.stroke = t.s
                    t.p.x = t.ex
                    t.p.y = t.ey
                    if (t.p.ending) ptrs.remove(t.p.id)
                }
                busy = false
                pump()
            }

            override fun onCancelled(g: GestureDescription?) {
                ptrs.clear()
                dirs.clear()
                busy = false
            }
        }, null)

        if (!ok) { busy = false; ptrs.clear(); dirs.clear() }
    }

    // ===== Con trỏ chuột trên màn hình =====
    private class CursorView(c: Context) : View(c) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }
        private val arrow = Path().apply {
            moveTo(0f, 0f); lineTo(0f, 24f); lineTo(7f, 18f); lineTo(12f, 29f)
            lineTo(16f, 27f); lineTo(11f, 17f); lineTo(19f, 17f); close()
        }

        override fun onDraw(canvas: Canvas) {
            val d = resources.displayMetrics.density
            canvas.scale(d, d)
            canvas.drawPath(arrow, fill)
            canvas.drawPath(arrow, edge)
        }
    }
}
