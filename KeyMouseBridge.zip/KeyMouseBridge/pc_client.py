#!/usr/bin/env python3
"""
Gửi bàn phím + chuột từ máy tính sang điện thoại Android.

Dùng:  python pc_client.py <IP_điện_thoại> <PIN> [ngang]
  - Cùng Wi-Fi: IP hiển thị trong app.
  - Qua cáp USB: chạy `adb forward tcp:9000 tcp:9000` rồi dùng IP 127.0.0.1
  - Thêm "ngang" nếu điện thoại đang xoay ngang.

Chỉ cần thư viện chuẩn (tkinter). Cửa sổ là "màn hình điện thoại":
vị trí chuột trong cửa sổ = vị trí chạm trên điện thoại.
"""
import socket
import sys
import tkinter as tk

PORT = 9000


def main():
    if len(sys.argv) < 3:
        sys.exit("Dùng: python pc_client.py <IP_điện_thoại> <PIN> [ngang]")
    host, pin = sys.argv[1], sys.argv[2]
    W, H = (900, 405) if "ngang" in sys.argv[3:] else (405, 900)

    root = tk.Tk()
    root.title("Phone Input - rê chuột vào đây để điều khiển")
    cv = tk.Canvas(root, width=W, height=H, bg="#111", highlightthickness=0, cursor="crosshair")
    cv.pack()
    cv.create_text(W / 2, H / 2, fill="#888", justify="center",
                   text="Chuột / phím trong cửa sổ này\n= thao tác trên điện thoại")
    cv.focus_set()

    sock = socket.create_connection((host, PORT), timeout=5)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sock.settimeout(None)

    def send(msg):
        try:
            sock.sendall((msg + "\n").encode("utf-8"))
        except OSError:
            root.destroy()

    send("AUTH " + pin)

    # ---- Chuột ----
    def pos(e):
        x = min(max(e.x / W, 0.0), 1.0)
        y = min(max(e.y / H, 0.0), 1.0)
        send(f"P {x:.4f} {y:.4f}")

    cv.bind("<Motion>", pos)
    for b in (1, 2, 3):  # trái, giữa, phải
        cv.bind(f"<ButtonPress-{b}>", lambda e, b=b: (pos(e), send(f"D {b - 1}")))
        cv.bind(f"<ButtonRelease-{b}>", lambda e, b=b: (pos(e), send(f"U {b - 1}")))

    def wheel(e):
        up = getattr(e, "delta", 0) > 0 or e.num == 4
        send("S 1" if up else "S -1")

    cv.bind("<MouseWheel>", wheel)  # Windows / macOS
    cv.bind("<Button-4>", wheel)    # Linux
    cv.bind("<Button-5>", wheel)

    # ---- Bàn phím ----
    pending = {}  # chống nhả-nhấn giả của auto-repeat trên Linux/X11

    def kname(e):
        c = e.char
        return c if c and c.isprintable() and c != " " else e.keysym.lower()

    def key_down(e):
        n = kname(e)
        t = pending.pop(n.lower(), None)
        if t is not None:
            root.after_cancel(t)
            return
        send(f"K {n} 1")

    def do_up(n):
        pending.pop(n.lower(), None)
        send(f"K {n} 0")

    def key_up(e):
        n = kname(e)
        pending[n.lower()] = root.after(30, do_up, n)

    cv.bind("<KeyPress>", key_down)
    cv.bind("<KeyRelease>", key_up)
    cv.bind("<Enter>", lambda e: cv.focus_set())
    cv.bind("<FocusOut>", lambda e: send("R"))  # mất focus -> nhả hết phím

    root.mainloop()


if __name__ == "__main__":
    main()
